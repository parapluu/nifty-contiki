#include "answer.h"

int
answer(int n) {
  return 42 + n;
}
