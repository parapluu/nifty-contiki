-module(tut).
-export([compile/0, setup/0, answer_property/1, test_func/0]).

-include_lib("proper/include/proper.hrl").
-include_lib("eunit/include/eunit.hrl").

compile() ->
    nifty:compile("answer.h", mote_answer, []).

setup() ->
    Handler = nifty_cooja:start("$CONTIKI/tools/cooja", "$PWD/simulation.csc", [gui]),
    Motes = nifty_cooja:motes(Handler),
    [ok = nifty_cooja:mote_listen(Handler, MoteID) || MoteID <- Motes],
    [true = nifty_cooja:wait_for_msg(Handler, MoteID, 1000, "Starting 'Process mote_answer'\n") || MoteID <- Motes],
    Handler.

answer_property(Motes) ->
    ?FORALL({I, Mote}, {integer(), oneof(Motes)},
            begin
		Handler = setup(),
		R = mote_answer:answer(Handler, Mote, I) =:= I+42,
		nifty_cooja:exit(),
		timer:sleep(100),
		R
            end).

test_func() ->
    Handler = setup(),
    Motes = nifty_cooja:motes(Handler),
    nifty_cooja:exit(),
    proper:quickcheck(answer_property(Motes), [{to_file, user}, {numtests, 2}]).

answer_test_() ->
    {timeout, 3600, ?_assertEqual(true, test_func())}.
