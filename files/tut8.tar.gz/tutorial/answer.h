#ifndef _NIFTY_TUTORIAL_ANSWER_H_
#define _NIFTY_TUTORIAL_ANSWER_H_

extern int answer(int n);

#endif /* _NIFTY_TUTORIAL_ANSWER_H_ */
