-module(tut).
-export([compile/0, tutorial/0]).

compile() ->
    nifty:compile("answer.h", mote_answer, [gui]).

tutorial() ->
    Handler = nifty_cooja:start("$CONTIKI/tools/cooja", "$PWD/simulation.csc"),
    Motes = nifty_cooja:motes(Handler),
    io:format("Motes: ~p~n", [Motes]),
    nifty_cooja:mote_listen(Handler, 1),
    nifty_cooja:wait_for_msg(Handler, 1, 1000, "Starting 'Process mote_answer'\n"),
    Ret = mote_answer:answer(Handler, 1, 10),
    nifty_cooja:exit(),
    Ret.

