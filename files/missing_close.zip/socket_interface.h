#include <stdint.h>

typedef union uip_ip6addr_t {
  uint8_t  u8[16];			/* Initializer, must come first. */
  uint16_t u16[8];
} uip_ip6addr_t;
typedef uip_ip6addr_t uip_ipaddr_t;

extern void init_server();

extern int create_socket();
extern int destroy_socket(int sd);

extern int listen(int sd, uint16_t port);
extern int unlisten(int sd);

extern int connect(int sd, uip_ipaddr_t *ip_addr, uint16_t port);

extern int close(int sd);
extern int send(int sd, const uint8_t *data, int datalen);
extern int send_str(int sd, const char *data);

extern uint16_t get_state(int sd);

extern void set_ip_addr(uip_ipaddr_t *ipaddr);
extern int set_rpl_root(uip_ipaddr_t *ipaddr, unsigned prefix_size);
extern void repair_rpl();

extern uip_ipaddr_t* get_addr();

extern uip_ipaddr_t* build_ip_addr(uint16_t b0, uint16_t b1, uint16_t b2, uint16_t b3, 
				   uint16_t b4, uint16_t b5, uint16_t b6, uint16_t b7);
