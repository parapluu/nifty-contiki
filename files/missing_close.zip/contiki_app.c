#include "contiki.h"
#include "dev/serial-line.h"

#if TARGET==z1
#include "dev/uart0.h"
#else
#include "dev/uart1.h"
#endif

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "/home/thegeorge/projects/priv/contiki_projects/proper_tests/socket_api/socket_interface/socket_interface.h"

#ifdef __MSP430__
#define strtoll(a,b,c) strtol((a),(b),(c))
#define strtoull(a,b,c) strtoul((a),(b),(c))
#define SIZEOF_FORMAT "%u\n"
#else
#define SIZEOF_FORMAT "%lu\n"
#endif

PROCESS(si, "Process si");
AUTOSTART_PROCESSES(&si);

static char nifty_buffer[128];

static char
hexstrtochar(const char* stream, char** next) {
    int i;
    unsigned sum=0, mul=0;
    char* act;
    for (i=0; i<2; i++) {
        act = (char*)(stream + i);
        if (i==1) {
            mul = 1;
        } else {
            mul = 16;
        }
        switch (*act) {
        case '0'...'9':
            sum += ((*act)-48) * mul;
            break;
        case 'a'...'f':
            sum += ((*act)-87) * mul;
            break;
        case 'A'...'F':
            sum += ((*act)-55) * mul;
            break;
        default:
            *next = ((char*)stream + 2);
            return (char)0;
        }
    }
    *next = ((char*)stream + 2);
    return (char)sum;
}

static int
write_mem(char* stream) {
    char* ptr;
    char* data;
    ptr = (char*)strtoull(stream, &data, 16);
    data++;
    while (((*data)!='\n') && ((*data)!=0)) {
        *ptr = hexstrtochar(data, &data);
        ptr++;
    }
    return snprintf(nifty_buffer, 128, "ok");
}

static int
allocate_mem(char* stream) {
    unsigned long size;
    char* stup;
    void* ptr;
    size = strtoul(stream, &stup, 10);
    ptr = malloc(size);
    return snprintf(nifty_buffer, 128, "%p", ptr);
}

static int
read_mem(char* stream) {
    char* ptr;
    unsigned long length;
    unsigned long i;
    unsigned forward;
    ptr = (char*)strtoull(stream, &stream, 16);
    stream++;
    length = strtoul(stream, &stream, 10);
    forward = 0;
    for (i=0; i<length; i++) {
        forward += snprintf(nifty_buffer+forward, 100-forward, "%.2X", (unsigned char)ptr[i]);
        if (i<length-1)
            forward += snprintf(nifty_buffer+forward, 100-forward, ",");
    }
    return forward;
}

static int
nifty_sizeof(char* stream) {
    char* typename = stream;
    return snprintf(nifty_buffer, 128, "undef");
}

static int
free_mem(char* stream) {
    void* ptr;
    ptr = (void*)strtoull(stream, &stream, 16);
    free(ptr);
    return snprintf(nifty_buffer, 128, "ok");
}




/* create call functions */

/*
* Variable transition inside of a function:
*	prepare -- are additional variable definitions required -> e.a. short int translation
*	to_c    -- translate the erlang values to c values
*	argument-- yield argument
*	to_erl  -- translate the return value and eventual output arguments to erlang types
*	cleanup -- cleanup memory used by the function
*/



int
niftycall_send(char* args) {
    int forward;
    char* nextarg = args;
    char* curarg;
    long c_retval;
    long carg_0;
    void* carg_1;
    long carg_2;
    curarg = nextarg;
    carg_0 = (int)strtoll(curarg, &nextarg, 16);
    curarg = nextarg;
    carg_1 = (void*)strtoll(curarg, &nextarg, 16);
    curarg = nextarg;
    carg_2 = (int)strtoll(curarg, &nextarg, 16);
    c_retval =
        (int)
        send(
            (int)carg_0
            ,
            (const uint8_t *)carg_1
            ,
            (int)carg_2
        );
    forward = snprintf(nifty_buffer, 128, "%ld", (long)c_retval);
    return forward;
    curarg++;
    nextarg++;
}

int
niftycall_send_str(char* args) {
    int forward;
    char* nextarg = args;
    char* curarg;
    long c_retval;
    long carg_0;
    void* carg_1;
    curarg = nextarg;
    carg_0 = (int)strtoll(curarg, &nextarg, 16);
    curarg = nextarg;
    carg_1 = (void*)strtoll(curarg, &nextarg, 16);
    c_retval =
        (int)
        send_str(
            (int)carg_0
            ,
            (const char *)carg_1
        );
    forward = snprintf(nifty_buffer, 128, "%ld", (long)c_retval);
    return forward;
    curarg++;
    nextarg++;
}

int
niftycall_listen(char* args) {
    int forward;
    char* nextarg = args;
    char* curarg;
    long c_retval;
    long carg_0;
    unsigned long carg_1;
    curarg = nextarg;
    carg_0 = (int)strtoll(curarg, &nextarg, 16);
    curarg = nextarg;
    carg_1 = (unsigned short)strtoull(curarg, &nextarg, 16);
    c_retval =
        (int)
        listen(
            (int)carg_0
            ,
            (uint16_t)carg_1
        );
    forward = snprintf(nifty_buffer, 128, "%ld", (long)c_retval);
    return forward;
    curarg++;
    nextarg++;
}

int
niftycall_set_rpl_root(char* args) {
    int forward;
    char* nextarg = args;
    char* curarg;
    long c_retval;
    void* carg_0;
    unsigned long carg_1;
    curarg = nextarg;
    carg_0 = (void*)strtoll(curarg, &nextarg, 16);
    curarg = nextarg;
    carg_1 = (unsigned int)strtoull(curarg, &nextarg, 16);
    c_retval =
        (int)
        set_rpl_root(
            (uip_ipaddr_t *)carg_0
            ,
            (unsigned int)carg_1
        );
    forward = snprintf(nifty_buffer, 128, "%ld", (long)c_retval);
    return forward;
    curarg++;
    nextarg++;
}

int
niftycall_set_ip_addr(char* args) {
    int forward;
    char* nextarg = args;
    char* curarg;
    void* carg_0;
    curarg = nextarg;
    carg_0 = (void*)strtoll(curarg, &nextarg, 16);
    set_ip_addr(
        (uip_ipaddr_t *)carg_0
    );
    forward = snprintf(nifty_buffer, 128, "ok");
    return forward;
    curarg++;
    nextarg++;
}

int
niftycall_get_state(char* args) {
    int forward;
    char* nextarg = args;
    char* curarg;
    unsigned long c_retval;
    long carg_0;
    curarg = nextarg;
    carg_0 = (int)strtoll(curarg, &nextarg, 16);
    c_retval =
        (unsigned short)
        get_state(
            (int)carg_0
        );
    forward = snprintf(nifty_buffer, 128, "%lu", (unsigned long)c_retval);
    return forward;
    curarg++;
    nextarg++;
}

int
niftycall_repair_rpl(char* args) {
    int forward;
    char* nextarg = args;
    char* curarg;
    repair_rpl(
    );
    forward = snprintf(nifty_buffer, 128, "ok");
    return forward;
    curarg++;
    nextarg++;
}

int
niftycall_init_server(char* args) {
    int forward;
    char* nextarg = args;
    char* curarg;
    init_server(
    );
    forward = snprintf(nifty_buffer, 128, "ok");
    return forward;
    curarg++;
    nextarg++;
}

int
niftycall_destroy_socket(char* args) {
    int forward;
    char* nextarg = args;
    char* curarg;
    long c_retval;
    long carg_0;
    curarg = nextarg;
    carg_0 = (int)strtoll(curarg, &nextarg, 16);
    c_retval =
        (int)
        destroy_socket(
            (int)carg_0
        );
    forward = snprintf(nifty_buffer, 128, "%ld", (long)c_retval);
    return forward;
    curarg++;
    nextarg++;
}

int
niftycall_unlisten(char* args) {
    int forward;
    char* nextarg = args;
    char* curarg;
    long c_retval;
    long carg_0;
    curarg = nextarg;
    carg_0 = (int)strtoll(curarg, &nextarg, 16);
    c_retval =
        (int)
        unlisten(
            (int)carg_0
        );
    forward = snprintf(nifty_buffer, 128, "%ld", (long)c_retval);
    return forward;
    curarg++;
    nextarg++;
}

int
niftycall_connect(char* args) {
    int forward;
    char* nextarg = args;
    char* curarg;
    long c_retval;
    long carg_0;
    void* carg_1;
    unsigned long carg_2;
    curarg = nextarg;
    carg_0 = (int)strtoll(curarg, &nextarg, 16);
    curarg = nextarg;
    carg_1 = (void*)strtoll(curarg, &nextarg, 16);
    curarg = nextarg;
    carg_2 = (unsigned short)strtoull(curarg, &nextarg, 16);
    c_retval =
        (int)
        connect(
            (int)carg_0
            ,
            (uip_ipaddr_t *)carg_1
            ,
            (uint16_t)carg_2
        );
    forward = snprintf(nifty_buffer, 128, "%ld", (long)c_retval);
    return forward;
    curarg++;
    nextarg++;
}

int
niftycall_get_addr(char* args) {
    int forward;
    char* nextarg = args;
    char* curarg;
    void* c_retval;
    c_retval =
        (void*)
        get_addr(
        );
    forward = snprintf(nifty_buffer, 128, "%lx", (long)c_retval);
    return forward;
    curarg++;
    nextarg++;
}

int
niftycall_build_ip_addr(char* args) {
    int forward;
    char* nextarg = args;
    char* curarg;
    void* c_retval;
    unsigned long carg_0;
    unsigned long carg_1;
    unsigned long carg_2;
    unsigned long carg_3;
    unsigned long carg_4;
    unsigned long carg_5;
    unsigned long carg_6;
    unsigned long carg_7;
    curarg = nextarg;
    carg_0 = (unsigned short)strtoull(curarg, &nextarg, 16);
    curarg = nextarg;
    carg_1 = (unsigned short)strtoull(curarg, &nextarg, 16);
    curarg = nextarg;
    carg_2 = (unsigned short)strtoull(curarg, &nextarg, 16);
    curarg = nextarg;
    carg_3 = (unsigned short)strtoull(curarg, &nextarg, 16);
    curarg = nextarg;
    carg_4 = (unsigned short)strtoull(curarg, &nextarg, 16);
    curarg = nextarg;
    carg_5 = (unsigned short)strtoull(curarg, &nextarg, 16);
    curarg = nextarg;
    carg_6 = (unsigned short)strtoull(curarg, &nextarg, 16);
    curarg = nextarg;
    carg_7 = (unsigned short)strtoull(curarg, &nextarg, 16);
    c_retval =
        (void*)
        build_ip_addr(
            (uint16_t)carg_0
            ,
            (uint16_t)carg_1
            ,
            (uint16_t)carg_2
            ,
            (uint16_t)carg_3
            ,
            (uint16_t)carg_4
            ,
            (uint16_t)carg_5
            ,
            (uint16_t)carg_6
            ,
            (uint16_t)carg_7
        );
    forward = snprintf(nifty_buffer, 128, "%lx", (long)c_retval);
    return forward;
    curarg++;
    nextarg++;
}

int
niftycall_create_socket(char* args) {
    int forward;
    char* nextarg = args;
    char* curarg;
    long c_retval;
    c_retval =
        (int)
        create_socket(
        );
    forward = snprintf(nifty_buffer, 128, "%ld", (long)c_retval);
    return forward;
    curarg++;
    nextarg++;
}

int
niftycall_close(char* args) {
    int forward;
    char* nextarg = args;
    char* curarg;
    long c_retval;
    long carg_0;
    curarg = nextarg;
    carg_0 = (int)strtoll(curarg, &nextarg, 16);
    c_retval =
        (int)
        close(
            (int)carg_0
        );
    forward = snprintf(nifty_buffer, 128, "%ld", (long)c_retval);
    return forward;
    curarg++;
    nextarg++;
}



void
save_serial(char* buffer, int length) {
    if (length>128) {
        printf("fail\n");
    } else {
        printf("%.*s\n", length, buffer);
    }
}


void
process_input(char* input) {
    long function;
    int retval;
    char* arguments;
    function = strtol(input, &arguments, 10);
    if ((!function) && (input==arguments)) {
        return; /* invalid input */
    }
    arguments++;
    switch (function) {
    case -0x01:
        retval = write_mem(arguments);
        break;
    case -0x02:
        retval = allocate_mem(arguments);
        break;
    case -0x03:
        retval = read_mem(arguments);
        break;
    case -0x04:
        retval = nifty_sizeof(arguments);
        break;
    case -0x05:
        retval = free_mem(arguments);
        break;
        /* generated functions */
    case 0:
        retval = niftycall_send(arguments);
        break;
    case 1:
        retval = niftycall_send_str(arguments);
        break;
    case 2:
        retval = niftycall_listen(arguments);
        break;
    case 3:
        retval = niftycall_set_rpl_root(arguments);
        break;
    case 4:
        retval = niftycall_set_ip_addr(arguments);
        break;
    case 5:
        retval = niftycall_get_state(arguments);
        break;
    case 6:
        retval = niftycall_repair_rpl(arguments);
        break;
    case 7:
        retval = niftycall_init_server(arguments);
        break;
    case 8:
        retval = niftycall_destroy_socket(arguments);
        break;
    case 9:
        retval = niftycall_unlisten(arguments);
        break;
    case 10:
        retval = niftycall_connect(arguments);
        break;
    case 11:
        retval = niftycall_get_addr(arguments);
        break;
    case 12:
        retval = niftycall_build_ip_addr(arguments);
        break;
    case 13:
        retval = niftycall_create_socket(arguments);
        break;
    case 14:
        retval = niftycall_close(arguments);
        break;
    }
    if (retval!=-1) {
        save_serial(nifty_buffer, retval);
    } else {
        retval = snprintf(nifty_buffer, 100, "badarg\n");
        save_serial(nifty_buffer, retval);
    }
}


PROCESS_THREAD(si, ev, data)
{
    PROCESS_BEGIN();
    /* UIP hack */
#if !(!WITH_UIP && !WITH_UIP6)
#if TARGET==z1
    uart0_set_input(serial_line_input_byte);
#else
    uart1_set_input(serial_line_input_byte);
#endif
    serial_line_init();
#endif
    for (;;) {
        PROCESS_WAIT_EVENT_UNTIL(ev == serial_line_event_message && data != NULL);
        process_input((char*)data);
    }
    PROCESS_END();
}
