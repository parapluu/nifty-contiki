#include "contiki.h"
#include "net/ip/uip.h"
#include "net/rpl/rpl.h"
#include "net/ip/tcp-socket.h"
#include "dev/button-sensor.h"

#define DEBUG DEBUG_PRINT
#include "net/ip/uip-debug.h"
#include "lib/crc16.h"

#include <stdio.h>
#include <stdlib.h>

#define BUFFER_SIZE 64
typedef struct socket_data {
  struct tcp_socket *socket;
  uint8_t id;
  uint8_t *inbuf;
  uint8_t *outbuf;
  uint8_t *last_msg_data;
  uint8_t last_msg_len;
} socket_data;

#define MAX_SOCKETS 10
static socket_data *sockets[MAX_SOCKETS];

#define CRC_START 0x0000

/* forward declerations */
static void event_callback(struct tcp_socket *s, void *ptr, tcp_socket_event_t event);
static int data_callback(struct tcp_socket *s, void *ptr, const uint8_t *input_data_ptr, int input_data_len);

/* implementation */
void
init_server() {
  int i;
  NETSTACK_MAC.off(1);
  for (i=0; i<MAX_SOCKETS; i++) {
    sockets[i] = NULL;
  }
}

int
create_socket() {
  int i, err;
  socket_data *d;
  for (i=0; i<MAX_SOCKETS; i++) {
    if (sockets[i]==NULL) {
      /* found empty spot */
      d = malloc(sizeof(socket_data));
      if (!d) {
	/* out of mem */
	return -1;
      }
      /* registrate in list */
      d->id = i;
      d->last_msg_data = NULL;
      sockets[i] = d;


      /* allocate memory for the socket struct */
      d->socket = malloc(sizeof(struct tcp_socket));

      /* allocate memory for the buffers */
      d->inbuf = malloc(BUFFER_SIZE);
      d->outbuf = malloc(BUFFER_SIZE);
      if (!(d->outbuf && d->inbuf && d->socket)) {
	/* out of mem */
	return -1;
      }

      /* register socket */
      err = tcp_socket_register(d->socket, d, 
				d->inbuf, BUFFER_SIZE,
				d->outbuf, BUFFER_SIZE,
				&data_callback,
				&event_callback);
      if (err==-1) {
	return -2;
      }
      return d->id;
    }
  }
  /* no free list entry */
  return -3;
}

int
destroy_socket(int sd) {
  socket_data *d;
  int err;

  if (sockets[sd]==NULL) {
    return -1;
  }
  d = sockets[sd];

  /* unregister socket */
  err = tcp_socket_unregister(d->socket);
  if (err==-1) {
    return -2;
  }

  /* free memory */
  free(d->socket);
  free(d->inbuf);
  free(d->outbuf);
  if (d->last_msg_data) {
    free(d->last_msg_data);
  }
  free(d);

  /* free entry in socket table */
  sockets[sd] = NULL;
  return 0;
}

int
listen(int sd, uint16_t port) {
  socket_data *d;
  int err;

  if (!sockets[sd]) {
    return -1;
  }
  d = sockets[sd];

  /* listen */
  err = tcp_socket_listen(d->socket, port);
  if (err==-1) {
    return -1;
  }
  return 0;
}

int
unlisten(int sd) {
  socket_data *d;
  int err;

  if (!sockets[sd]) {
    return -1;
  }
  d = sockets[sd];

  err = tcp_socket_unlisten(d->socket);
  if (err==-1) {
    return -1;
  }
  return 0;
}

int
connect(int sd, uip_ipaddr_t *ip_addr, uint16_t port) {
  socket_data *d;
  int err;
  /* printf("DEBUG:"); */
  /* PRINT6ADDR(ip_addr); */
  /* printf("\n"); */
  if (!sockets[sd]) {
    return -1;
  }
  d = sockets[sd];

  err = tcp_socket_connect(d->socket, ip_addr, port);
  if (err==-1) {
    return -1;
  }
  return 0;
}

int
close(int sd) {
  socket_data *d;
  int err;

  if (!sockets[sd]) {
    return -1;
  }
  d = sockets[sd];

  err = tcp_socket_close(d->socket);
  if (err==-1) {
    return -1;
  }
  return 0;
}

int
send(int sd, const uint8_t *data, int datalen) {
  socket_data *d;
  int err;

  if (!sockets[sd]) {
    return -1;
  }
  d = sockets[sd];

  printf("EVENT:%u\n", crc16_data(data, datalen, CRC_START));

  err = tcp_socket_send(d->socket, data, datalen);
  if (err==-1) {
    return -1;
  }
  return 0;
}

int
send_str(int sd, const char *data) {
  socket_data *d;
  int err;

  if (!sockets[sd]) {
    return -1;
  }
  d = sockets[sd];

  err = tcp_socket_send_str(d->socket, data);
  if (err==-1) {
    return -1;
  }
  return 0;
}

uint16_t
get_state(int sd) {
  socket_data *d;

  if (!sockets[sd]) {
    return -1;
  }
  d = sockets[sd];
  
  return (((d->socket->flags) << 8) | (d->socket->c->tcpstateflags));
}

void
set_ip_addr(uip_ipaddr_t *ipaddr) {
  uip_ds6_set_addr_iid(ipaddr, &uip_lladdr);
  uip_ds6_addr_add(ipaddr, 0, ADDR_AUTOCONF);
}

int
set_rpl_root(uip_ipaddr_t *ipaddr, unsigned prefix_size) {
  struct uip_ds6_addr *root_if;
  root_if = uip_ds6_addr_lookup(ipaddr);
  if(root_if != NULL) {
    rpl_dag_t *dag;
    dag = rpl_set_root(RPL_DEFAULT_INSTANCE,ipaddr);
    rpl_set_prefix(dag, ipaddr, prefix_size);
    return 0;
  } else {
    return -1;
  }
}

void
repair_rpl() {
  rpl_repair_root(RPL_DEFAULT_INSTANCE);
}

uip_ipaddr_t *
build_ip_addr(uint16_t b0, uint16_t b1, uint16_t b2, uint16_t b3, 
	      uint16_t b4, uint16_t b5, uint16_t b6, uint16_t b7)
{
  uip_ipaddr_t *addr=malloc(sizeof(uip_ipaddr_t));
  uip_ip6addr(addr, b0, b1, b2, b3, b4, b5, b6, b7);
  return addr;
}

uip_ipaddr_t*
get_addr()
{
  int i;
  for(i = 0; i < UIP_DS6_ADDR_NB; i++) {
    if ((uip_ds6_if.addr_list[i].type==1) 
	&& ((&uip_ds6_if.addr_list[i].ipaddr)->u16[0]==0xaaaa)) {
      return &uip_ds6_if.addr_list[i].ipaddr;
    }
  }
  return NULL;
}

static void
event_callback(struct tcp_socket *s, 
	       void *ptr, 
	       tcp_socket_event_t event) {
  switch (event) {
  case TCP_SOCKET_CONNECTED:
    printf("EVENT:connected\n");
    break;
  case TCP_SOCKET_CLOSED:
    printf("EVENT:closed\n");
    break;
  case TCP_SOCKET_TIMEDOUT:
    printf("EVENT:timeout\n");
    break;
  case TCP_SOCKET_ABORTED:
    printf("EVENT:aborted\n");
    break;
  case TCP_SOCKET_DATA_SENT:
    printf("EVENT:data_sent\n");
    break;
  default:
    printf("EVENT:error\n");
  }
}

static int
data_callback(struct tcp_socket *s,
	      void *ptr,
	      const uint8_t *input_data_ptr,
	      int input_data_len) {
  /* socket_data *d = (socket_data*)ptr; */
  /* free last message */
  /* if (d->last_msg_data) { */
  /*   free(d->last_msg_data); */
  /*   d->last_msg_data = NULL; */
  /* } */
  /* /\* locally store last message *\/ */
  /* d->last_msg_data = malloc(input_data_len); */
  /* d->last_msg_len = input_data_len; */
  
  /* memcpy(d->last_msg_data, input_data_ptr, input_data_len); */
  printf("EVENT:received\n");
  printf("EVENT:%u\n", crc16_data(input_data_ptr, input_data_len, CRC_START));

  return 0; /* consume all bytes */
}
